import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./Login.css";
import { useHistory } from "react-router-dom";
function Login() {
  const Hist = useHistory();
  const [user, setUser] = useState({
    email: "",
    password: "",
  });
  const loginUser=async (e)=>{
   e.preventDefault();
   const {email,password} = user;

   const re = await fetch('/signin',{
	   method:"POST",
	   headers:{
		"Content-Type":"application/json"
	   },
	   body:JSON.stringify({
		email,password
	 })
   });
   const data = re.json();
   if(re.status===400||!data){
	  window.alert("UnSucessfull=>  ");
	  console.log("mail=> "+email+" Pass=> "+password);
	  console.log("Res=> "+re.status);
	  console.log("Data => "+data);

   }else{
	window.alert("LOGIN Sucessfull");
	Hist.push("/");
   }
  }
  let name,value;
  const handle = (e)=>{
	name = e.target.name;
    value = e.target.value;
    setUser({...user,[name]:value})
  }
  return (
    <>
      <div class="global-container mt-5">
        <div class="card login-form">
          <div class="card-body">
            <h3 class="card-title text-center">Log in Page</h3>
            <div class="card-text">
              <form method='POST'>
                <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <input
                    type="email"
                    name="email"
                    value={user.email}
					onChange=
                         {handle}
					
                    class="form-control form-control-sm"
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                  />
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <a href="#j" style={{ float: "right", "font-size": "12px" }}>
                    Forgot password?
                  </a>
                  <input
                    name="password"
                    value={user.password}
					onChange=
                         {handle}
                    type="password"
                    class="form-control form-control-sm"
                    id="exampleInputPassword1"
                  />
                </div>
                <button type="submit" onClick={loginUser} class="btn btn-primary btn-block">
                  Sign in
                </button>
                <div class="sign-up">
                  Don't have an account?{" "}
                  <button
                    style={{ border: "none" }}
                    onClick={() => {
                      Hist.push("/signup");
                    }}
                  >
                    Signup
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

	  
    </>
  );
}

export default Login;
