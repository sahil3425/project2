import React from 'react'

function Home() {
    return (
        <div>
        <p className="pt-5">Welcome</p>
        <p>We are full stack web developer</p>
        </div>
    )
}

export default Home
