import React, { useState } from "react";
import "./Signup.css";
import "bootstrap/dist/css/bootstrap.css";

import { useHistory } from "react-router-dom";
function Signup() {
  const Hist = useHistory();
  const [user, setUser] = useState({
    name: "",
    email: "",
    phone: "",
    work: "",
    password: "",
    cpassword: "",
  });
  let name,value;
  const handleInputs = (e) => {
    console.log("handleinputs => ",e);
    name = e.target.name;
    value = e.target.value;
    setUser({...user,[name]:value})
  };
const PostData = async (e)=>{
   e.preventDefault();
   const {name,email,phone,work,password,cpassword} = user;
   const res=await fetch("/register",{
      method:"POST",
      headers:{
         "Content-Type":"application/json"
      },
      body:JSON.stringify({
         name,email,phone,work,password,cpassword
      })
   });
   const r = await res.json();
   if(r.status===422||!r){
window.alert("Invalid ");
console.log("Invalid");
   }
   else{
    window.alert("Registration Succesfull ");
    console.log("Registration Succesfull");
    Hist.push("/login");
   }
}

  return (
    <>
      <h2 class="card-title text-center">Register </h2>

      <section className="sign__up">
        <div class="container d-flex justify-content-evenly">
          <div class="row justify-content-center ">
            <div class="col-md-5">
              <div class="card">
                <div class="card-body py-md-4">
                  <form method="POST" className="form1">
                    <div class="form-group">
                      <input
                        type="text"
                        class="form-control"
                        name="name"
                        id="name"
                        value={user.name}
                        onChange={handleInputs}
                        placeholder="Name"
                      />
                    </div>
                    <div class="form-group">
                      <input
                        type="email"
                        class="form-control"
                        name="email"
                        id="email"
                        value={user.email}
                        onChange={handleInputs}
                        placeholder="Email"
                      />
                    </div>
                    <div class="form-group">
                      <input
                        type="phone"
                        class="form-control"
                        name="phone"
                        id="phone"
                        value={user.phone}
                        onChange={handleInputs}
                        placeholder="Phone"
                      />
                    </div>
                    <div class="form-group">
                      <input
                        type="work"
                        class="form-control"
                        name="work"
                        id="work"
                        value={user.work}
                        onChange={handleInputs}
                        placeholder="work"
                      />
                    </div>

                    <div class="form-group">
                      <input
                        type="password"
                        class="form-control"
                        name="password"
                        id="password"
                        value={user.password}
                        onChange={handleInputs}
                        placeholder="Password"
                      />
                    </div>
                    <div class="form-group">
                      <input
                        type="password"
                        class="form-control"
                        name="cpassword"
                        id="confirm-password"
                        value={user.cpassword}
                        onChange={handleInputs}
                        placeholder="confirm-password"
                      />
                    </div>
                    <div class="d-flex flex-row align-items-center justify-content-between">
                      <button
                        style={{ border: "none" }}
                        onClick={() => {
                          Hist.push("/login");
                        }}
                      >
                        Login
                      </button>
                      <button onClick={PostData} class="btn btn-primary">Create Account</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <lottie-player
            src="https://assets4.lottiefiles.com/packages/lf20_q5pk6p1k.json"
            background="transparent"
            className="lottie"
            speed="1"
            style={{ width: "300px", height: "600px" }}
            loop
            autoplay
          ></lottie-player>
        </div>
      </section>
    </>
  );
}

export default Signup;
